/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_290(unsigned *p)
{
    *p = 3083065422U;
}

unsigned addval_195(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_303()
{
    return 3348711618U;
}

void setval_223(unsigned *p)
{
    *p = 1482880919U;
}

unsigned addval_278(unsigned x)
{
    return x + 3347663039U;
}

unsigned addval_305(unsigned x)
{
    return x + 2425393240U;
}

void setval_326(unsigned *p)
{
    *p = 2425444524U;
}

unsigned addval_421(unsigned x)
{
    return x + 3347660959U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_171(unsigned *p)
{
    *p = 2429651390U;
}

unsigned addval_450(unsigned x)
{
    return x + 2244199049U;
}

unsigned addval_233(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_470()
{
    return 2496563646U;
}

unsigned getval_371()
{
    return 3286272328U;
}

unsigned addval_332(unsigned x)
{
    return x + 3687105161U;
}

void setval_449(unsigned *p)
{
    *p = 3223375497U;
}

void setval_424(unsigned *p)
{
    *p = 3527983753U;
}

unsigned getval_471()
{
    return 2447411528U;
}

unsigned getval_252()
{
    return 2464188744U;
}

void setval_340(unsigned *p)
{
    *p = 2425406089U;
}

unsigned addval_256(unsigned x)
{
    return x + 2496563558U;
}

unsigned getval_409()
{
    return 2430638408U;
}

void setval_270(unsigned *p)
{
    *p = 3680555401U;
}

void setval_110(unsigned *p)
{
    *p = 3372270217U;
}

unsigned getval_105()
{
    return 3229929867U;
}

void setval_407(unsigned *p)
{
    *p = 3286272456U;
}

unsigned addval_456(unsigned x)
{
    return x + 3380138377U;
}

void setval_271(unsigned *p)
{
    *p = 3531915905U;
}

unsigned getval_399()
{
    return 3247492745U;
}

unsigned getval_168()
{
    return 3285092802U;
}

void setval_354(unsigned *p)
{
    *p = 3525889673U;
}

unsigned getval_312()
{
    return 3224424073U;
}

void setval_251(unsigned *p)
{
    *p = 3224949128U;
}

unsigned addval_438(unsigned x)
{
    return x + 2425409801U;
}

unsigned addval_148(unsigned x)
{
    return x + 3523793289U;
}

unsigned addval_257(unsigned x)
{
    return x + 3523265161U;
}

unsigned getval_209()
{
    return 3373846921U;
}

unsigned addval_119(unsigned x)
{
    return x + 2430634314U;
}

void setval_272(unsigned *p)
{
    *p = 3221799553U;
}

unsigned addval_253(unsigned x)
{
    return x + 3286272360U;
}

unsigned getval_383()
{
    return 3383021193U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
